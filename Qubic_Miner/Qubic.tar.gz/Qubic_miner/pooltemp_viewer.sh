#! /usr/bin/zsh

# URL of the webpage
URL="https://pooltemp.qubic.solutions/info?miner=YSCRXJLLNHCIDGVBKIVAELKPLVNAEBPKESVRFBDEDFQKPVKLEEWPWUCGXSSK&list=true"

# Function to fetch and display information
get_mining_info() {
    # Fetch the JSON response from the URL
    response=$(curl -s "$URL")

    # Extract specific information from the JSON response
    epoch=$(echo "$response" | jq -r '.epoch')
    iterrate=$(echo "$response" | jq -r '.iterrate')
    devices=$(echo "$response" | jq -r '.devices')
    solutions=$(echo "$response" | jq -r '.solutions')
    label=$(echo "$response" | jq -r '.device_list[0].label')
    last_iterrate=$(echo "$response" | jq -r '.device_list[0].last_iterrate')

    # Display the extracted information
    echo "Epoch: $epoch"
    echo "Iteration Rate: $iterrate"
    echo "Devices: $devices"
    echo "Solutions: $solutions"
    echo "Label: $label"
    echo "Last Iteration Rate: $last_iterrate"
}

# Display the mining information
get_mining_info
