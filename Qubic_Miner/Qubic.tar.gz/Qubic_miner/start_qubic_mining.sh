#! /usr/bin/zsh

#id_YSCRXJLLNHCIDGVBKIVAELKPLVNAEBPKESVRFBDEDFQKPVKLEEWPWUCGXSSK

# Start Qubic mining
./rqiner-armv7-musleabihf -t 8 -i YSCRXJLLNHCIDGVBKIVAELKPLVNAEBPKESVRFBDEDFQKPVKLEEWPWUCGXSSK > qubic_mining.log 2>&1 &


# Display message
echo "Qubic mining process started and running in the background."


