#! /usr/bin/zsh

wget https://github.com/Qubic-Solutions/rqiner-builds/releases/download/v0.3.19/rqiner-armv7-musleabihf
