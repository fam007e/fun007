#! /usr/bin/zsh

# Find and kill the Qubic mining process
pkill -f "rqiner-armv7-musleabihf"

# Optionally, you can add more commands here if needed
